const mongoose = require('mongoose');

const SignalSchema = new mongoose.Schema({
	signal: {
		type: String,
		required: true,
	},
	green: {
		type: Number,
		required: true,
	},
	red: {
		type: Number,
		required: true,
	},
	yellow: {
		type: Number,
		required: true,
	}
});

module.exports = mongoose.model('Signal', SignalSchema);
