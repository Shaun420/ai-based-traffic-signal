const mongoose = require('mongoose');

const StateSchema = new mongoose.Schema({
	state: {
		city: {
			region: {
				location: [
				{
					signal: {
						type: String,
						required: true
					},
					green: {
						type: Number,
						required: true
					},
					red: {
						type: Number,
						required: true
					},
					yellow: {
						type: Number,
						required: true
					}
				}
				]
			}
		}
	}
});

module.exports = mongoose.model('State', StateSchema);
