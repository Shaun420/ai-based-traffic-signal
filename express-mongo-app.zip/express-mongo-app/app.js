const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const signalRoute = require('./routes/signal');

// Load environment variables
dotenv.config();

// Initialize the app
const app = express();

// Middleware to parse JSON data
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
.then(() => console.log('MongoDB connected...'))
.catch(err => console.log(err));

// Routes
app.use('/signal', signalRoute);

// Define a simple home route
app.get('/', (req, res) => {
	res.send('Welcome to Traffic Management Dashboard');
});

// Start the server
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server running on port ${port}`));
