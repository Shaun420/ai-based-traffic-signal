const express = require('express');
const router = express.Router();
//const Signal = require('../models/Signal');
const m_State = require('../models/Location');

// @route   GET /signal
// @desc    Get one signal data
router.get('/', async (req, res) => {
	console.log(req.body)
	try {
		var s = await m_State.findOne().exec();
		console.log("Response:");
		console.log(s);
		res.json(s);
	} catch (err) {
		res.status(500).json({ message: err.message });
	}
});

module.exports = router;
